export interface BookingResult {
  id: string;
  title: string;
  startsAt: Date;
  endsAt: Date;
  userId: string;
  status: 'active' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}
