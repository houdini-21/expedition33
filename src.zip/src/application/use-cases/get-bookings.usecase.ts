import { GetBookingsQuery } from '../dto/queries/get-bookings.query';
import { BookingRepositoryPort } from '../ports/booking.repository.port';

export class GetBookingsUseCase {
  constructor(private readonly repo: BookingRepositoryPort) {}

  async execute(query: GetBookingsQuery) {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 20;
    return this.repo.list({ ...query, page, pageSize });
  }
}
