import { GetBookingByIdQuery } from '../dto/queries/get-booking-by-id.query';
import { BookingRepositoryPort } from '../ports/booking.repository.port';
import { BookingNotFoundError, NotOwnerError } from '../errors/booking.errors';
import { BookingResult } from '../dto/results/booking.result';

export class GetBookingByIdUseCase {
  constructor(private readonly repo: BookingRepositoryPort) {}

  async execute(query: GetBookingByIdQuery): Promise<BookingResult> {
    const item = await this.repo.findById(query.id);
    if (!item) throw new BookingNotFoundError();
    if (item.userId !== query.userId) throw new NotOwnerError();
    return { ...item };
  }
}
