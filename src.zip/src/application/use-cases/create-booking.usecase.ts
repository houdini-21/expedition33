import { CreateBookingCommand } from '../dto/commands/create-booking.command';
import { BookingRepositoryPort } from '../ports/booking.repository.port';
import { UnitOfWorkPort } from '../ports/unit-of-work.port';
import { OverlappingBookingError } from '../errors/booking.errors';

export class CreateBookingUseCase {
  constructor(
    private readonly repo: BookingRepositoryPort,
    private readonly uow: UnitOfWorkPort,
  ) {}

  async execute(cmd: CreateBookingCommand): Promise<{ id: string }> {
    const { userId, title, startsAt, endsAt } = cmd.input;
    if (startsAt >= endsAt) throw new Error('InvalidTimeRange');

    const overlap = await this.repo.existsOverlap(userId, startsAt, endsAt);
    if (overlap) throw new OverlappingBookingError();

    return this.uow.runInTransaction(async () => {
      const id = await this.repo.create({ userId, title, startsAt, endsAt });
      return { id };
    });
  }
}
