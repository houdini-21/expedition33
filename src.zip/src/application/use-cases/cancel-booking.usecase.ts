import { CancelBookingCommand } from '../dto/commands/cancel-booking.command';
import { BookingRepositoryPort } from '../ports/booking.repository.port';
import { UnitOfWorkPort } from '../ports/unit-of-work.port';
import {
  BookingNotFoundError,
  NotOwnerError,
  BookingCancelledError,
} from '../errors/booking.errors';

export class CancelBookingUseCase {
  constructor(
    private readonly repo: BookingRepositoryPort,
    private readonly uow: UnitOfWorkPort,
  ) {}

  async execute(cmd: CancelBookingCommand): Promise<void> {
    const {
      id,
      input: { userId },
    } = cmd;
    const booking = await this.repo.findById(id);
    if (!booking) throw new BookingNotFoundError();
    if (booking.userId !== userId) throw new NotOwnerError();
    if (booking.status === 'cancelled') throw new BookingCancelledError();

    await this.uow.runInTransaction(async () => {
      await this.repo.cancel(id);
    });
  }
}
